<?php
namespace App\Enums;
enum UserType: string {
	case hospital = 'hospital';
	case doctor = 'doctor';
}
