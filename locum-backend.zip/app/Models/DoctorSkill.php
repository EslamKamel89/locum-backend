<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DoctorSkill extends Model {
	/** @use HasFactory<\Database\Factories\DoctorSkillFactory> */
	use HasFactory;
	protected $guarded = [];

	//! Relationships
}
