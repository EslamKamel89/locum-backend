
<script>
        function getcities(id) {
       alert(id);
       $("#city").slideToggle();
    //    $.ajax({
    //         url: `<?php echo e(url('ajax/cities/')); ?>/${id}`,
    //         method: "GET",
    //         datatype: "json",
    //         success: function (data) {
    //             console.log(data);
    //             $("#city").html(data);
    //         },
    //    })
        }


</script>
<?php /**PATH C:\xampp\htdocs\locum\locum-backend\resources\views\web\ajax\getcities.blade.php ENDPATH**/ ?>