
<script>
        function getcities(id) {
       $.ajax({
            url: `<?php echo e(url('ajax/cities/')); ?>/${id}`,
            method: "GET",
            datatype: "json",
            success: function (data) {
                $('#city_id').html("");
                $('#city_id').append("<option value=''>Select City</option>");
                data.forEach(element => {
                    $('#city_id').append(`<option value="${element.id}">${element.name}</option>`);
                });
            },
       })
        }


</script>
<?php /**PATH C:\xampp\htdocs\locum\locum-backend\resources\views/web/ajax/getcities.blade.php ENDPATH**/ ?>